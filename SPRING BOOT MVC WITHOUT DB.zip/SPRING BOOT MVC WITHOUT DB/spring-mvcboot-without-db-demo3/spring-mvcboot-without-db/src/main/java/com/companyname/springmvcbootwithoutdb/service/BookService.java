package com.companyname.springmvcbootwithoutdb.service;

import com.companyname.springmvcbootwithoutdb.model.Book;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class BookService {
    List<Book> books= new ArrayList<>(Arrays.asList(
            new Book("B01","Head First Java",589.26),
            new Book("B02","Head First Servlets",7889),
            new Book("B03","Spring Head Start",5589)
    ));
    public List<Book> getAllBooks() {
        return books;
    }

    public Book getBookById(String id) {
        return books.stream().filter(b->b.getId().equals(id)).findFirst().get();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void updateBook(String id, Book book) {
        for(int i=0;i<books.size();i++){
            Book b=books.get(i);
            if(b.getId().equals(id)){
                books.set(i,book);
            }
        }
    }

    public void deleteBook(String id) {
        books.removeIf(b->b.getId().equals(id));
    }
}
