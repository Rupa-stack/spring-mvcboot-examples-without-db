package com.companyname.springmvcbootwithoutdb.service;

import com.companyname.springmvcbootwithoutdb.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class StudentService {

    List<Student> students = new ArrayList(Arrays.asList(
            new Student("1","sunny","ECE"),
            new Student("2","Rohan","CSE"),
            new Student("3","sam","EEE"),
            new Student("4","Rahul","CIVIL")
    ));

    public List<Student> getAllStudents(){
        return students;
    }

    public Student getStudentById(String id) {
        return students.stream().filter(s->s.getId().equals(id)).findFirst().get();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void updateStudent(String id, Student student) {
        for(int i=0;i<students.size();i++)
        {
            Student s=students.get(i);
            if(s.getId().equals(id)){
                students.set(i,student);
            }
        }
    }

    public void deleteStudent(String id) {
        students.removeIf(s-> s.getId().equals(id));
    }
}
