package com.companyname.springmvcbootwithoutdb.controller;

import com.companyname.springmvcbootwithoutdb.model.Student;
import com.companyname.springmvcbootwithoutdb.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class StudentController {

    @Autowired
    StudentService studentService;

    @RequestMapping("/students")
    public List<Student> getAllStudents(){
        return studentService.getAllStudents();
    }

    @RequestMapping("/student/{id}")
    public Student getStudentById(@PathVariable String id){
        return studentService.getStudentById(id);
    }

    @RequestMapping(method=RequestMethod.POST, value="/students")
    public void addStudent(@RequestBody Student student){
         studentService.addStudent(student);
    }

    @RequestMapping(method = RequestMethod.PUT, value="/student/{id}")
    public void updateStudent(@RequestBody Student student, @PathVariable String id){
         studentService.updateStudent(id,student);
    }

    @RequestMapping(method = RequestMethod.DELETE, value="/student/{id}")
    public void updateStudent(@PathVariable String id){
        studentService.deleteStudent(id);
    }
}
