package com.companyname.springbootmvcwithoutdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcWithoutDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcWithoutDbApplication.class, args);
	}

}
