package com.companyname.springbootmvcwithoutdb.controllers;

import com.companyname.springbootmvcwithoutdb.model.Topic;
import com.companyname.springbootmvcwithoutdb.service.TopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TopicsController {

    @Autowired
    TopicService topicService;

    //get all topics available
    @RequestMapping("/topics")
    public List<Topic> getAllTopics() {
       return topicService.getAllTopics();
    }

    //get a topic by id
    @RequestMapping("/topics/{id}")
    public Topic getTopic(@PathVariable String id){
        return topicService.getTopic(id);
    }

    //add a new topic
    @RequestMapping(method = RequestMethod.POST, value= "/topics")
    public void addTopic(@RequestBody Topic topic){
        topicService.addTopic(topic);
    }

    //update a specific topic
    @RequestMapping(method = RequestMethod.PUT, value= "/topics/{id}")
    public void updateTopic(@RequestBody Topic topic, @PathVariable String id){
        topicService.updateTopic(id,topic);
    }

    //delete a specific topic
    @RequestMapping(method = RequestMethod.DELETE, value= "/topics/{id}")
    public void deleteTopic(@PathVariable String id){
        topicService.deleteTopic(id);
    }
}
