package com.companyname.springmvcbootwithoutdb.controller;

import com.companyname.springmvcbootwithoutdb.model.Employee;
import com.companyname.springmvcbootwithoutdb.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @RequestMapping("/employees")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @RequestMapping("employee/{id}")
    public Employee getEmployeeById(@PathVariable String id) {
        return employeeService.getEmployeeById(id);
    }

    @RequestMapping(method = RequestMethod.POST, value="/employees")
    public void addEmployee(@RequestBody Employee employee){
        employeeService.addEmployee(employee);
    }

    @RequestMapping(method = RequestMethod.PUT, value="/employees/{id}")
    public void updateEmployee(@RequestBody Employee employee, @PathVariable String id){
        employeeService.updateEmployee(id,employee);
    }

    @RequestMapping(method = RequestMethod.DELETE, value="/employee/{id}")
    public void deleteEmployee(@PathVariable String id){
        employeeService.deleteEmployee(id);
    }

}
