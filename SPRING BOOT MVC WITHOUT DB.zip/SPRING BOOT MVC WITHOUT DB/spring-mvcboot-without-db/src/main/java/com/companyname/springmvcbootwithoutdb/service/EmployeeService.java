package com.companyname.springmvcbootwithoutdb.service;

import com.companyname.springmvcbootwithoutdb.model.Employee;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class EmployeeService {

    public List<Employee> employees = new ArrayList(Arrays.asList(new Employee("101","John","HR",20000.50),
            new Employee("102","Sam","IT",48700.74),
            new Employee("103","Patrick","ACCOUNTS",87960.50),
            new Employee("104","Donald","MANAGEMENT",9500.50)));

    public List<Employee> getAllEmployees() {
        return employees;
    }

    public Employee getEmployeeById(String id) {

        return employees.stream().filter(t->t.getId().equals(id)).findFirst().get();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void updateEmployee(String id, Employee employee) {
        for(int i=0;i<employees.size();i++)
        {
            Employee e= employees.get(i);
            if(e.getId().equals(id)){
                employees.set(i,employee);
            }
        }
    }

    public void deleteEmployee(String id) {
        employees.removeIf(t-> t.getId().equals(id));
    }
}
