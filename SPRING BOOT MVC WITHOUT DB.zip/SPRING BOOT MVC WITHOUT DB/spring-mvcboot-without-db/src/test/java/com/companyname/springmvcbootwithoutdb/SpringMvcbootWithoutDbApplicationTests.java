package com.companyname.springmvcbootwithoutdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcbootWithoutDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
